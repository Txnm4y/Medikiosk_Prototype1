/** @type {import('next').NextConfig} */

const isDev = process.env.NODE_ENV !== 'production';

// Content-Security-Policy — locked to same-origin by default.
// - script-src allows 'unsafe-eval' only in dev, because Next.js Fast
//   Refresh/HMR relies on eval(); production builds don't need it.
// - style-src allows 'unsafe-inline' because Tailwind's runtime theme
//   toggle (AppShell.jsx sets `--font-scale` and the high-contrast class via
//   the CSSOM) mutates styles at runtime. Tighten this with a nonce later if
//   it becomes a concern.
// - connect-src is 'self' only — when real integrations (hospital HIS,
//   ABHA/ABDM gateway, speech-to-text/OCR providers) are wired in, add each
//   real endpoint explicitly here. Do not widen this to '*'.
const csp = [
  "default-src 'self'",
  `script-src 'self'${isDev ? " 'unsafe-eval'" : ''}`,
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "font-src 'self'",
  "connect-src 'self'",
  "frame-ancestors 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "object-src 'none'",
].join('; ');

const securityHeaders = [
  { key: 'Content-Security-Policy', value: csp },
  { key: 'X-Frame-Options', value: 'DENY' },
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  {
    // Speech input and document-photo capture are part of this app's actual
    // feature set (see ReadAloudButton / DocumentUploadArea), so mic/camera
    // stay allowed for same-origin use; everything else not needed is off.
    key: 'Permissions-Policy',
    value: 'camera=(self), microphone=(self), geolocation=(), interest-cohort=()',
  },
  // Harmless to send even over plain HTTP (browsers ignore it there) —
  // actual HTTP->HTTPS redirection is a hosting/reverse-proxy concern, see
  // SECURITY.md, "Force HTTPS".
  {
    key: 'Strict-Transport-Security',
    value: 'max-age=63072000; includeSubDomains; preload',
  },
  { key: 'X-DNS-Prefetch-Control', value: 'on' },
];

const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false, // don't advertise "X-Powered-By: Next.js"
  async headers() {
    return [
      {
        source: '/:path*',
        headers: securityHeaders,
      },
    ];
  },
};

module.exports = nextConfig;
