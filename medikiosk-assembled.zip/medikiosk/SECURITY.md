# Security notes — MediKiosk scaffold

This maps the full security checklist against what this repo actually is
today, so nothing on the list gets lost even though most of it can't be
*truly* done yet.

**The honest starting point:** this is a static Next.js frontend scaffold.
There is no backend, no database, no API route, no `.git` history, and no
real secret anywhere in the project — every "backend" call goes through
`lib/mocks.js`. That means roughly half of the items below are backend/infra
concerns that are premature until a real server exists, not things a
frontend-only codebase can satisfy on its own. Claiming otherwise would be
misleading. What's below is organized as: **done now**, **partially
mitigated at the UI layer**, and **not applicable until there's a backend —
here's exactly what to do when you build it.**

## Done in this pass

| Item | What changed |
|---|---|
| Add security headers | `next.config.js` now sends CSP, `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, `Referrer-Policy`, `Permissions-Policy`, `Strict-Transport-Security`, and drops `X-Powered-By`. |
| Force HTTPS | `Strict-Transport-Security` header added. Actual TLS termination/redirect is a **hosting-layer** concern — Vercel/Netlify do this automatically; a self-hosted deploy needs a reverse proxy (Nginx/Caddy) or an explicit redirect based on `x-forwarded-proto`. |
| Scan dependencies | Checked: the pinned `next@14.2.5` carries **CVE-2025-29927** (critical, middleware authorization bypass, CVSS 9.1) plus several other fixed-later issues. Next.js 14 as a whole reached end-of-life Oct 2025; its final patched release is `14.2.35`. Bumped `package.json` to `14.2.35`. Run `npm install` then `npm audit` — I couldn't run either myself in this sandbox (no network access). Longer-term, plan a migration to Next 15/16, since 14.x no longer receives any security fixes at all. |
| Hide API keys / use a public DB key correctly | Added `.env.example` documenting the split: no `NEXT_PUBLIC_` prefix = server-only secret; `NEXT_PUBLIC_` prefix = visible in the browser bundle. A Supabase/Firebase-style "anon"/"public" key is fine to expose *only* once RLS is enforced on every table it can reach — the key's secrecy isn't what protects the data, RLS is. Never put a service-role/admin key in a `NEXT_PUBLIC_` variable. |
| Purge git secrets | No `.git` folder was included in this upload, so there's nothing to purge here. Added `.gitignore` (env files, `node_modules`, build output) so nothing leaks once a real repo exists. If a real repo elsewhere already has a committed secret: **rotate that credential immediately** — cleaning history with `git filter-repo`/BFG matters, but rotation is what actually neutralizes an already-exposed key, since old clones/forks keep the history regardless. |
| Validate all input (partial) | Login form now trims/caps length and rejects empty submits before calling `mockLogin`. The existing phone/ABHA/Aadhaar length check on `/welcome` was already doing this. **This is UX only** — see "Enforce server-side authentication" below for why it doesn't count as real validation. |
| Escape user content | Verified: every piece of user/AI-generated text in this codebase (chief complaint, history answers, summary sections, extracted document fields) renders through plain JSX interpolation, which React auto-escapes. No `dangerouslySetInnerHTML` anywhere. Keep it that way — if the Summary screen's editable text ever needs rich formatting, sanitize (e.g. DOMPurify) before any `dangerouslySetInnerHTML`, don't add it raw. |
| Restrict file uploads (partial) | `/upload` already filtered by MIME type; added a 10MB client-side size cap alongside it. Both are UX hints only — see "Restrict file uploads" below. |
| Secure session cookies (partial, mock) | Replaced the raw `localStorage.setItem` calls with `lib/session.js`, which now attaches an absolute expiry (15 min) to the mock session, and added an idle-timeout auto-logout (5 min of no activity) plus periodic expiry checks on the dashboard. This is still a `localStorage` token, not a real secure session — see below for what actually replaces it. |
| Rate limit login / bot protection (partial, cosmetic) | Login now locks out for 30s after 5 failed attempts, client-side. This resets on refresh and is trivially scriptable around — it buys nothing against a real attacker. Real protection has to be server-side. |
| Encrypt sensitive data (partial, UI layer) | The dashboard's ABHA ID and phone number are now masked by default (last 4 digits visible) with a Show/Hide toggle, so they're not sitting in plain view on a shared kiosk screen. This is exposure *minimization*, not encryption — there's no data store yet to encrypt. |

## Not applicable yet — do this when the backend exists

These items describe controls that live in a server, a database, or a
deployment pipeline. None of those exist in this repo yet, so there's
nothing to "add" — implementing them now would mean writing backend code
against a database that isn't there, which would be fictional, not secure.
Treat this section as the spec for whoever builds that part.

- **Enforce server-side authentication.** `mockLogin()` is 100% client-side
  and always trusts whatever the client claims. A real login must be a
  server endpoint that checks credentials against a real store and issues
  the session itself — the client should never be the thing deciding
  "login succeeded."
- **Hash passwords.** No accounts are stored anywhere yet. When they are:
  bcrypt or argon2, never a homemade scheme, never plaintext, ever.
- **Lock record access / block field tampering.** Every "past visits" or
  profile query must be scoped server-side to what the *authenticated*
  caller is authorized to see — never trust a patient/record ID the client
  sends. Same for writes: re-validate and re-authorize every field
  server-side before it touches a real EMR/HIS; client state (React state,
  `IntakeContext`) is always attacker-controllable.
- **Parameterized queries.** There's no database or query anywhere in this
  repo. Once there is: always use parameter binding / prepared statements
  or your ORM's parameterization — never string-concatenate user input into
  a query.
- **Enable row level security.** Applies once a Postgres-style database
  (e.g. Supabase) is in place: turn on RLS on every table by default and
  write explicit per-table policies, then test them using the same anon key
  the client will use — RLS is what makes exposing that anon key safe.
- **Trim API responses.** Once real endpoints exist, only return the fields
  the authenticated caller actually needs — don't shape a response by just
  serializing an entire internal patient record.
- **Add bot protection (server-side).** A honeypot field plus a real
  challenge (hCaptcha/reCAPTCHA) belongs on the real login/intake endpoints,
  not in client JS.
- **Rate limit login (server-side).** Per-IP and per-account limits (e.g. via
  a WAF/API gateway, or middleware backed by Redis) on the real login
  endpoint — the client-side cooldown added in this pass is UX friction
  only.
- **Restrict file uploads (server-side).** Independently re-check file type
  by content/magic-byte sniffing (never trust the client-supplied MIME type)
  and size, and run malware/AV scanning before storing anything — these are
  medical documents.
- **Secure session cookies (real version).** Replace `lib/session.js`'s
  `localStorage` entirely with a server-set `httpOnly`, `Secure`,
  `SameSite=Strict` cookie, and check auth in `middleware.js` / a server
  component rather than client-side JS. `localStorage` is readable by any
  script on the origin (i.e. stealable via XSS); a real token should never
  live there.
- **Encrypt sensitive data (real version).** Encryption in transit is
  covered by HTTPS once deployed (see above). Encryption at rest (DB-level
  or field-level for ABHA IDs, phone numbers, clinical notes) is a database
  feature to configure once a real database exists.

## One thing to flag specifically

If you do add `middleware.js` later for auth checks (a common Next.js App
Router pattern), make sure you're on a patched Next.js version first —
**CVE-2025-29927** is exactly a middleware-based authorization bypass, and
it's specifically what the `14.2.35` bump above fixes.
