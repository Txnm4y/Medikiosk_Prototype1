'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useIntake } from '@/context/IntakeContext';
import translations from '@/lib/translations';
import { mockTranscribeSpeech } from '@/lib/mocks';
import { SECTIONS, historyScript } from '@/lib/historyScript';
// Reusing the exact same audio-icon / read-aloud stub used on every other
// kiosk screen, rather than building a second one, so behavior stays
// identical (and, later, shares one real-TTS wiring point).
import ReadAloudButton from '@/components/welcome/ReadAloudButton';

// historyScript's very first step deliberately uses key: 'chiefComplaint' —
// the same name as the dedicated IntakeContext.chiefComplaint field (see
// README's IntakeContext table). Every other step's `key` is a free-form
// historyAnswers field name. So this one key is special-cased to go to
// setChiefComplaint(); everything else goes through updateHistoryAnswer().
const CHIEF_COMPLAINT_KEY = 'chiefComplaint';

function sectionLabelFor(t, sectionId) {
  const section = SECTIONS.find((s) => s.id === sectionId);
  return (section && t[section.labelKey]) || sectionId;
}

export default function IntakePage() {
  const router = useRouter();
  const { language, historyAnswers, chiefComplaint, setChiefComplaint, updateHistoryAnswer } =
    useIntake();
  const t = translations[language]?.intake ?? translations.en.intake;

  const [stepIndex, setStepIndex] = useState(0);
  const [draftText, setDraftText] = useState('');
  const [micState, setMicState] = useState('idle'); // 'idle' | 'listening' | 'transcribing'

  const isComplete = stepIndex >= historyScript.length;
  const step = isComplete ? null : historyScript[stepIndex];

  // Pre-fill the textarea if this step already has an answer (e.g. the
  // patient stepped forward then came back — not currently reachable via UI,
  // but keeps this screen correct if back-navigation is added later).
  function currentValueFor(currentStep) {
    if (!currentStep) return '';
    if (currentStep.key === CHIEF_COMPLAINT_KEY) return chiefComplaint || '';
    return historyAnswers[currentStep.key] || '';
  }

  function goToStep(nextIndex, prefill) {
    setStepIndex(nextIndex);
    setDraftText(prefill ?? '');
    setMicState('idle');
  }

  function commitAnswer(key, value) {
    if (key === CHIEF_COMPLAINT_KEY) {
      setChiefComplaint(value);
    } else {
      updateHistoryAnswer(key, value);
    }
  }

  function handleMicToggle() {
    if (micState === 'idle') {
      setMicState('listening');
      return;
    }
    if (micState === 'listening') {
      setMicState('transcribing');
      mockTranscribeSpeech(null).then(({ text }) => {
        setDraftText(text);
        setMicState('idle');
      });
    }
    // 'transcribing' -> ignore taps until the mock resolves.
  }

  function handleContinue() {
    commitAnswer(step.key, draftText.trim());
    goToStep(stepIndex + 1, currentValueFor(historyScript[stepIndex + 1]));
  }

  function handleOptionSelect(value) {
    // Tapping an option answers and advances immediately — no need to also
    // press Continue (per historyScript.js's documented 'choice' behavior).
    commitAnswer(step.key, value);
    goToStep(stepIndex + 1, currentValueFor(historyScript[stepIndex + 1]));
  }

  function handleDone() {
    router.push('/upload');
  }

  const progressPercent = Math.round(
    (Math.min(stepIndex, historyScript.length) / historyScript.length) * 100
  );

  if (isComplete) {
    return (
      <div className="space-y-6">
        <div className="rounded-2xl border border-brand-border bg-brand-surface p-8 text-center shadow-sm">
          <div
            className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-brand-primary text-3xl text-brand-primaryText"
            aria-hidden="true"
          >
            ✓
          </div>
          <p className="mt-6 text-lg text-brand-text">{t.completeBody}</p>
          <button
            type="button"
            onClick={handleDone}
            className="mt-8 min-h-[48px] w-full rounded-2xl bg-brand-primary px-6 py-4 text-lg font-semibold text-brand-primaryText shadow-sm transition hover:opacity-90"
          >
            {t.continueButton}
          </button>
        </div>
      </div>
    );
  }

  const questionText = step.text[language] ?? step.text.en;
  const isChoiceStep = step.type === 'choice';
  const isFirstStep = stepIndex === 0;
  const canContinue = !isFirstStep || draftText.trim().length > 0;

  return (
    <div className="space-y-6">
      {/* Progress */}
      <div className="rounded-2xl border border-brand-border bg-brand-surface p-4 shadow-sm">
        <div className="flex items-center justify-between gap-4">
          <span className="text-sm font-medium text-brand-muted">
            {sectionLabelFor(t, step.section)}
          </span>
          <span className="text-sm text-brand-muted">
            {stepIndex + 1} / {historyScript.length}
          </span>
        </div>
        <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-brand-bg">
          <div
            className="h-full rounded-full bg-brand-primary transition-all"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Question */}
      <div className="rounded-2xl border border-brand-border bg-brand-surface p-8 shadow-sm">
        <div className="flex items-start justify-between gap-4">
          <h1 className="text-2xl font-semibold text-brand-text">{questionText}</h1>
          <ReadAloudButton label={t.readAloud} />
        </div>

        {/* Mic input */}
        <div className="mt-8 flex flex-col items-center gap-3">
          <button
            type="button"
            onClick={handleMicToggle}
            disabled={micState === 'transcribing'}
            aria-pressed={micState === 'listening'}
            className={`flex h-20 w-20 items-center justify-center rounded-full border text-3xl shadow-sm transition ${
              micState === 'listening'
                ? 'border-brand-primary bg-brand-primary text-brand-primaryText'
                : micState === 'transcribing'
                  ? 'cursor-not-allowed border-brand-border bg-brand-border text-brand-muted'
                  : 'border-brand-border bg-brand-bg text-brand-text hover:opacity-80'
            }`}
          >
            🎤
          </button>
          <p className="text-base text-brand-muted" role="status">
            {micState === 'listening'
              ? t.micListening
              : micState === 'transcribing'
                ? t.micTranscribing
                : t.micIdle}
          </p>
        </div>

        {/* Editable transcript / free-text answer */}
        <textarea
          value={draftText}
          onChange={(e) => setDraftText(e.target.value)}
          rows={3}
          className="mt-6 w-full resize-y rounded-2xl border border-brand-border bg-brand-bg p-4 text-base text-brand-text outline-none focus:border-brand-primary"
        />

        <button
          type="button"
          onClick={handleContinue}
          disabled={!canContinue}
          className={`mt-6 min-h-[48px] w-full rounded-2xl px-6 py-4 text-lg font-semibold shadow-sm transition ${
            canContinue
              ? 'bg-brand-primary text-brand-primaryText hover:opacity-90'
              : 'cursor-not-allowed bg-brand-border text-brand-muted'
          }`}
        >
          {t.continueButton}
        </button>

        {/* Tappable options, for 'choice' steps only */}
        {isChoiceStep && (
          <div className="mt-6">
            <p className="mb-3 text-center text-sm text-brand-muted">{t.orChooseOption}</p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {step.options.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => handleOptionSelect(option.value)}
                  className="min-h-[48px] rounded-2xl border border-brand-border bg-brand-surface px-4 py-3 text-base font-medium text-brand-text transition hover:opacity-80"
                >
                  {option.label[language] ?? option.label.en}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
