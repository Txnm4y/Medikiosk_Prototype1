import '../styles/globals.css';
import { IntakeProvider } from '@/context/IntakeContext';
import AppShell from '@/components/AppShell';

export const metadata = {
  title: 'MediKiosk',
  description: 'Patient self-service clinical history-taking kiosk for hospital OPDs',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <IntakeProvider>
          <AppShell>{children}</AppShell>
        </IntakeProvider>
      </body>
    </html>
  );
}
