'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useIntake } from '@/context/IntakeContext';
import translations from '@/lib/translations';
import { mockLogin } from '@/lib/mocks';
import { saveSession } from '@/lib/session';

// Client-side login-attempt friction only, reset on every page refresh and
// trivially bypassed by anyone scripting the form directly — this is NOT a
// substitute for real protection. Real brute-force / bot protection (rate
// limiting by IP + account, CAPTCHA/hCaptcha, account lockout, WAF rules)
// must live server-side once a real login endpoint exists. See
// SECURITY.md, "Rate limit login" and "Add bot protection".
const MAX_ATTEMPTS_BEFORE_COOLDOWN = 5;
const COOLDOWN_MS = 30 * 1000;

export default function DashboardLoginPage() {
  const router = useRouter();
  const { language } = useIntake();
  const t = translations[language]?.login ?? translations.en.login;

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [cooldownUntil, setCooldownUntil] = useState(null);

  const isCoolingDown = cooldownUntil !== null && Date.now() < cooldownUntil;

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');

    if (isCoolingDown) {
      setError(t.tooManyAttempts);
      return;
    }

    // Basic client-side validation. This only improves UX (catches empty
    // submits before spending a network round trip) — it is not a security
    // control. The real backend must independently validate/sanitize every
    // field again; never trust anything the client claims to have checked.
    // See SECURITY.md, "Validate all input".
    const trimmedUsername = username.trim();
    if (!trimmedUsername || !password) {
      setError(t.genericError);
      return;
    }

    setIsSubmitting(true);
    const result = await mockLogin(trimmedUsername, password);

    if (result.success) {
      // See lib/session.js for why this mock uses localStorage and what
      // needs to change (httpOnly cookie + server-side check) for real auth.
      saveSession({ username: trimmedUsername, token: result.token });
      setFailedAttempts(0);
      router.push('/dashboard/home');
      return;
    }

    const nextAttempts = failedAttempts + 1;
    setFailedAttempts(nextAttempts);
    if (nextAttempts >= MAX_ATTEMPTS_BEFORE_COOLDOWN) {
      setCooldownUntil(Date.now() + COOLDOWN_MS);
      setFailedAttempts(0);
    }

    // Deliberately generic, regardless of whether the username or the
    // password was wrong — avoids leaking which part was incorrect
    // (account enumeration).
    setError(result.error || t.genericError);
    setIsSubmitting(false);
  }

  return (
    <div className="mx-auto max-w-md">
      <div className="rounded-2xl border border-brand-border bg-brand-surface p-8 shadow-sm">
        <h1 className="text-2xl font-semibold text-brand-text">{t.title}</h1>
        <p className="mt-2 text-base text-brand-muted">{t.subtitle}</p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-brand-text">
              {t.usernameLabel}
            </label>
            <input
              id="username"
              type="text"
              autoComplete="username"
              maxLength={100}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder={t.usernamePlaceholder}
              className="mt-1 w-full rounded-xl border border-brand-border bg-brand-bg px-3 py-2 text-base text-brand-text outline-none focus:border-brand-primary"
            />
          </div>

          <div>
            <label htmlFor="password" className="block text-sm font-medium text-brand-text">
              {t.passwordLabel}
            </label>
            <input
              id="password"
              type="password"
              autoComplete="current-password"
              maxLength={128}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder={t.passwordPlaceholder}
              className="mt-1 w-full rounded-xl border border-brand-border bg-brand-bg px-3 py-2 text-base text-brand-text outline-none focus:border-brand-primary"
            />
          </div>

          {error && (
            <p role="alert" className="rounded-xl bg-brand-bg px-3 py-2 text-sm text-red-600">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={isSubmitting || isCoolingDown}
            className={`w-full rounded-xl px-4 py-2.5 text-base font-semibold shadow-sm transition ${
              isSubmitting || isCoolingDown
                ? 'cursor-not-allowed bg-brand-border text-brand-muted'
                : 'bg-brand-primary text-brand-primaryText hover:opacity-90'
            }`}
          >
            {isSubmitting ? t.submitting : t.loginButton}
          </button>
        </form>

        <p className="mt-6 text-xs text-brand-muted">{t.demoHint}</p>
      </div>
    </div>
  );
}
