'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useIntake } from '@/context/IntakeContext';
import translations from '@/lib/translations';
import { readSession, clearSession } from '@/lib/session';

// Auto-logout after this much inactivity on the dashboard. Kiosk/staff
// dashboards run on shared hospital terminals, so an unattended logged-in
// session is a real exposure risk (anyone walking up sees patient data) —
// this is independent of, and shorter than, the absolute session lifetime
// enforced by lib/session.js.
const IDLE_TIMEOUT_MS = 5 * 60 * 1000;
const ACTIVITY_EVENTS = ['mousemove', 'keydown', 'click', 'touchstart', 'scroll'];

// ----------------------------------------------------------------------------
// Static dummy data — no real patient-records backend yet. Shape mirrors
// what a real "past visits" list would plausibly return so swapping in a
// real fetch later only touches how this array is populated, not how it's
// rendered.
//
// SECURITY NOTE for whoever wires up the real fetch: this list, and the
// profile below, must come from a server endpoint that (a) requires a
// valid authenticated session and (b) scopes the query to records that
// specific logged-in user/staff member is authorized to see — never trust
// a patient/record id supplied by the client alone, and never return more
// fields than the caller is entitled to. See SECURITY.md, "Lock record
// access" and "Trim API responses".
const DUMMY_VISITS = [
  {
    id: 'v3',
    date: '2026-08-20',
    chiefComplaint: 'Fever and body ache',
    oneLiner: 'Viral fever, prescribed paracetamol and rest.',
    detail:
      'Reported 2 days of fever and generalized body ache. Examined, no focal findings. Advised paracetamol 500mg, ORS, and rest for 3 days. Follow up if fever persists beyond 4 days.',
  },
  {
    id: 'v2',
    date: '2026-05-03',
    chiefComplaint: 'Persistent cough',
    oneLiner: 'Mild bronchitis, cough syrup prescribed.',
    detail:
      'Reported dry cough for about a week, worse at night, no fever. Chest examination unremarkable. Prescribed cough syrup and advised steam inhalation. No red-flag symptoms noted.',
  },
  {
    id: 'v1',
    date: '2026-01-11',
    chiefComplaint: 'Routine health checkup',
    oneLiner: 'Annual checkup — all parameters normal.',
    detail:
      'Routine annual checkup. Blood pressure, blood sugar, and weight within normal range. No complaints. Advised to continue current diet and activity levels, recheck in a year.',
  },
];

// Static dummy profile — a real build would read this from the patient's
// ABHA-linked record, not local state.
const DUMMY_PROFILE = {
  name: 'Asha Patil',
  abha: '14-2345-6789-0123',
  phone: '+91 98765 43210',
};

/** Masks all but the last `visibleCount` digits of a value, keeping any
 * non-digit separators (dashes, spaces, +) in place so the shape stays
 * readable. Used to keep national health IDs / phone numbers off-screen by
 * default on a shared kiosk terminal — reduces shoulder-surfing exposure
 * even though the underlying data here is just dummy demo data. */
function maskDigits(value, visibleCount = 4) {
  if (!value) return value;
  const totalDigits = (value.match(/\d/g) || []).length;
  let seen = 0;
  return value
    .split('')
    .map((ch) => {
      if (!/\d/.test(ch)) return ch;
      seen += 1;
      return seen > totalDigits - visibleCount ? ch : '•';
    })
    .join('');
}

export default function DashboardHomePage() {
  const router = useRouter();
  const { language, resetIntake } = useIntake();
  const t = translations[language]?.home ?? translations.en.home;

  const [checkedSession, setCheckedSession] = useState(false);
  const [expandedId, setExpandedId] = useState(null);
  const [revealSensitive, setRevealSensitive] = useState(false);

  function handleLogout() {
    clearSession();
    router.push('/dashboard/login');
  }

  useEffect(() => {
    if (!readSession()) {
      router.replace('/dashboard/login');
      return;
    }
    setCheckedSession(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [router]);

  // Idle auto-logout + a periodic absolute-expiry check, so a session ends
  // even if the terminal is left logged in and untouched.
  useEffect(() => {
    if (!checkedSession) return undefined;

    let idleTimer = null;
    function resetIdleTimer() {
      if (idleTimer) clearTimeout(idleTimer);
      idleTimer = setTimeout(handleLogout, IDLE_TIMEOUT_MS);
    }

    ACTIVITY_EVENTS.forEach((evt) => window.addEventListener(evt, resetIdleTimer));
    resetIdleTimer();

    const expiryCheck = setInterval(() => {
      if (!readSession()) handleLogout();
    }, 30 * 1000);

    return () => {
      if (idleTimer) clearTimeout(idleTimer);
      clearInterval(expiryCheck);
      ACTIVITY_EVENTS.forEach((evt) => window.removeEventListener(evt, resetIdleTimer));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [checkedSession]);

  function handleStartNewIntake() {
    resetIntake();
    router.push('/welcome');
  }

  function toggleExpanded(id) {
    setExpandedId((prev) => (prev === id ? null : id));
  }

  if (!checkedSession) {
    return null;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4 rounded-2xl border border-brand-border bg-brand-surface p-8 shadow-sm">
        <div>
          <h1 className="text-2xl font-semibold text-brand-text">{t.title}</h1>
          <p className="mt-2 text-base text-brand-muted">{t.subtitle}</p>
        </div>
        <button
          type="button"
          onClick={handleLogout}
          className="shrink-0 rounded-xl border border-brand-border px-3 py-2 text-sm font-medium text-brand-muted transition hover:bg-brand-bg hover:text-brand-text"
        >
          {t.logoutButton}
        </button>
      </div>

      {/* Profile */}
      <div className="rounded-2xl border border-brand-border bg-brand-surface p-6 shadow-sm">
        <div className="flex items-center justify-between gap-4">
          <h2 className="text-lg font-semibold text-brand-text">{t.profileHeading}</h2>
          <button
            type="button"
            onClick={() => setRevealSensitive((prev) => !prev)}
            className="shrink-0 rounded-xl border border-brand-border px-3 py-1.5 text-sm font-medium text-brand-muted transition hover:bg-brand-bg hover:text-brand-text"
          >
            {revealSensitive ? t.hideButton : t.showButton}
          </button>
        </div>
        <dl className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
          <div>
            <dt className="text-sm text-brand-muted">{t.profileName}</dt>
            <dd className="text-base font-medium text-brand-text">{DUMMY_PROFILE.name}</dd>
          </div>
          <div>
            <dt className="text-sm text-brand-muted">{t.profileAbha}</dt>
            <dd className="text-base font-medium text-brand-text">
              {revealSensitive ? DUMMY_PROFILE.abha : maskDigits(DUMMY_PROFILE.abha)}
            </dd>
          </div>
          <div>
            <dt className="text-sm text-brand-muted">{t.profilePhone}</dt>
            <dd className="text-base font-medium text-brand-text">
              {revealSensitive ? DUMMY_PROFILE.phone : maskDigits(DUMMY_PROFILE.phone)}
            </dd>
          </div>
        </dl>
      </div>

      {/* Start New Intake */}
      <button
        type="button"
        onClick={handleStartNewIntake}
        className="w-full rounded-2xl bg-brand-primary px-6 py-4 text-lg font-semibold text-brand-primaryText shadow-sm transition hover:opacity-90"
      >
        {t.startIntakeButton}
      </button>

      {/* Past visits */}
      <div className="rounded-2xl border border-brand-border bg-brand-surface p-6 shadow-sm">
        <h2 className="text-lg font-semibold text-brand-text">{t.visitsHeading}</h2>

        <div className="mt-4 space-y-3">
          {DUMMY_VISITS.map((visit) => {
            const isExpanded = expandedId === visit.id;
            return (
              <div key={visit.id} className="rounded-2xl border border-brand-border bg-brand-bg p-4">
                <button
                  type="button"
                  onClick={() => toggleExpanded(visit.id)}
                  aria-expanded={isExpanded}
                  className="flex w-full items-start justify-between gap-4 text-left"
                >
                  <div>
                    <p className="text-sm text-brand-muted">{visit.date}</p>
                    <p className="mt-0.5 text-base font-medium text-brand-text">{visit.chiefComplaint}</p>
                    <p className="mt-0.5 text-sm text-brand-muted">{visit.oneLiner}</p>
                  </div>
                  <span className="shrink-0 pt-1 text-brand-muted" aria-hidden="true">
                    {isExpanded ? '▲' : '▼'}
                  </span>
                </button>

                {isExpanded && (
                  <p className="mt-3 border-t border-brand-border pt-3 text-sm text-brand-text">
                    {visit.detail}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
