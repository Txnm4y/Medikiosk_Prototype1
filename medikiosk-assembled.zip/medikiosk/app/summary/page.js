'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useIntake } from '@/context/IntakeContext';
import translations from '@/lib/translations';
import { mockGenerateSummary, mockSubmitToHospitalSystem } from '@/lib/mocks';
import { buildSummarySections } from '@/lib/buildSummarySections';
import ReadAloudButton from '@/components/welcome/ReadAloudButton';
import SummarySection from '@/components/summary/SummarySection';
import SubmissionSuccess from '@/components/summary/SubmissionSuccess';

// Fixed display order for the clinical note — matches the standard clinical
// format requested for this screen. buildSummarySections() returns objects
// keyed by these same ids, so this array only controls ordering + which
// translated label each id maps to.
const SECTION_ORDER = [
  'chiefComplaint',
  'hpi',
  'pastHistory',
  'drugAllergy',
  'familyHistory',
  'personalHistory',
  'reviewOfSystems',
  'priorInvestigations',
];

export default function SummaryPage() {
  const router = useRouter();
  const {
    language,
    chiefComplaint,
    historyAnswers,
    uploadedDocuments,
    setSummary,
    resetIntake,
  } = useIntake();

  const t = translations[language]?.summary ?? translations.en.summary;

  // 'generating' -> mockGenerateSummary() in flight
  // 'ready'      -> sections editable, awaiting Confirm & Submit
  // 'submitting' -> mockSubmitToHospitalSystem() in flight
  // 'submitted'  -> success state
  const [status, setStatus] = useState('generating');
  const [sections, setSections] = useState([]); // [{ id, labelKey, defaultLabel, text }]
  const [referenceId, setReferenceId] = useState(null);

  useEffect(() => {
    let cancelled = false;

    mockGenerateSummary({ chiefComplaint, historyAnswers, uploadedDocuments }).then((generated) => {
      if (cancelled) return;
      const built = buildSummarySections({
        chiefComplaint,
        historyAnswers,
        uploadedDocuments,
        generated,
      });
      // Preserve SECTION_ORDER regardless of the order buildSummarySections returns.
      const byId = Object.fromEntries(built.map((s) => [s.id, s]));
      setSections(SECTION_ORDER.map((id) => byId[id]).filter(Boolean));
      setStatus('ready');
    });

    return () => {
      cancelled = true;
    };
    // Intentionally run once on mount — this screen summarizes whatever was
    // collected on prior screens; it doesn't need to regenerate if the user
    // edits text locally afterward.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function handleSectionChange(id, value) {
    setSections((prev) => prev.map((s) => (s.id === id ? { ...s, text: value } : s)));
  }

  function handleSubmit() {
    setStatus('submitting');

    const summaryPayload = {
      chiefComplaint: sections.find((s) => s.id === 'chiefComplaint')?.text ?? chiefComplaint,
      sections: Object.fromEntries(sections.map((s) => [s.id, s.text])),
      generatedAt: new Date().toISOString(),
    };

    setSummary(summaryPayload);

    mockSubmitToHospitalSystem(summaryPayload).then((result) => {
      setReferenceId(result.referenceId);
      setStatus('submitted');
    });
  }

  function handleDone() {
    resetIntake();
    router.push('/');
  }

  if (status === 'submitted') {
    return <SubmissionSuccess t={t} referenceId={referenceId} onDone={handleDone} />;
  }

  const isGenerating = status === 'generating';
  const isSubmitting = status === 'submitting';

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-brand-border bg-brand-surface p-8 shadow-sm">
        <div className="flex items-start justify-between gap-4">
          <h1 className="text-3xl font-semibold text-brand-text">{t.title}</h1>
          <ReadAloudButton label={t.readAloud} />
        </div>
        <p className="mt-4 text-lg text-brand-text">{t.subtitle}</p>
        <p className="mt-2 text-sm text-brand-muted">{t.editableHint}</p>
      </div>

      {isGenerating ? (
        <div className="rounded-2xl border border-brand-border bg-brand-surface p-8 text-center shadow-sm">
          <div
            className="mx-auto h-8 w-8 animate-spin rounded-full border-4 border-brand-border border-t-brand-primary"
            aria-hidden="true"
          />
          <p className="mt-4 text-base text-brand-muted" role="status">
            {t.generating}
          </p>
        </div>
      ) : (
        <>
          <div className="space-y-4">
            {sections.map((section) => (
              <SummarySection
                key={section.id}
                title={t[section.labelKey] ?? section.defaultLabel}
                value={section.text}
                onChange={(value) => handleSectionChange(section.id, value)}
                readAloudLabel={t.readAloud}
                disabled={isSubmitting}
              />
            ))}
          </div>

          <div className="rounded-2xl border border-brand-border bg-brand-surface p-6 shadow-sm">
            <button
              type="button"
              onClick={handleSubmit}
              disabled={isSubmitting}
              className={`min-h-[48px] w-full rounded-2xl px-6 py-4 text-lg font-semibold shadow-sm transition ${
                isSubmitting
                  ? 'cursor-not-allowed bg-brand-border text-brand-muted'
                  : 'bg-brand-primary text-brand-primaryText hover:opacity-90'
              }`}
            >
              {isSubmitting ? t.submitting : t.submitButton}
            </button>
            {isSubmitting && (
              <p className="mt-2 text-center text-sm text-brand-muted" role="status">
                {t.submittingHint}
              </p>
            )}
          </div>
        </>
      )}
    </div>
  );
}
