'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useIntake } from '@/context/IntakeContext';
import translations from '@/lib/translations';
// Reusing the exact same audio-icon / read-aloud stub component built for the
// Welcome screen, rather than creating a second one, so the two screens use
// identical behavior (and, later, identical real-TTS wiring).
import ReadAloudButton from '@/components/welcome/ReadAloudButton';

export default function ConsentPage() {
  const router = useRouter();
  const { language, setConsentGiven } = useIntake();
  const [checked, setChecked] = useState(false);

  const t = translations[language]?.consent ?? translations.en.consent;

  function handleAgree() {
    if (!checked) return;
    setConsentGiven(true);
    router.push('/intake');
  }

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-brand-border bg-brand-surface p-8 shadow-sm">
        <div className="flex items-start justify-between gap-4">
          <h1 className="text-3xl font-semibold text-brand-text">{t.title}</h1>
          <ReadAloudButton label={t.readAloud} />
        </div>

        <p className="mt-6 text-lg text-brand-text">{t.intro}</p>

        <div className="mt-6 rounded-2xl border border-brand-border bg-brand-bg p-6">
          <h2 className="text-lg font-semibold text-brand-text">{t.dataUseHeading}</h2>
          <ul className="mt-3 space-y-2 text-base text-brand-text">
            <li className="flex gap-2">
              <span aria-hidden="true">•</span>
              <span>{t.dataUsePoint1}</span>
            </li>
            <li className="flex gap-2">
              <span aria-hidden="true">•</span>
              <span>{t.dataUsePoint2}</span>
            </li>
            <li className="flex gap-2">
              <span aria-hidden="true">•</span>
              <span>{t.dataUsePoint3}</span>
            </li>
          </ul>
        </div>

        <p className="mt-4 text-sm text-brand-muted">{t.dpdpNotice}</p>

        <label className="mt-8 flex min-h-[48px] cursor-pointer items-center gap-3 rounded-2xl border border-brand-border bg-brand-bg px-4 py-3">
          <input
            type="checkbox"
            checked={checked}
            onChange={(e) => setChecked(e.target.checked)}
            className="h-6 w-6 shrink-0 accent-brand-primary"
          />
          <span className="text-base text-brand-text">{t.agree}</span>
        </label>

        <button
          type="button"
          onClick={handleAgree}
          disabled={!checked}
          className={`mt-8 min-h-[48px] w-full rounded-2xl px-6 py-4 text-lg font-semibold shadow-sm transition ${
            checked
              ? 'bg-brand-primary text-brand-primaryText hover:opacity-90'
              : 'cursor-not-allowed bg-brand-border text-brand-muted'
          }`}
        >
          {t.agreeButton}
        </button>
      </div>
    </div>
  );
}
