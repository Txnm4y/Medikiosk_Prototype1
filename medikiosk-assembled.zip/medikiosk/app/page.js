import Link from 'next/link';

const routes = [
  ['/welcome', 'Kiosk screen 1 — Welcome'],
  ['/consent', 'Kiosk screen 2 — Consent'],
  ['/intake', 'Kiosk screen 3 — Intake'],
  ['/upload', 'Kiosk screen 4 — Upload documents'],
  ['/summary', 'Kiosk screen 5 — Summary'],
  ['/dashboard/login', 'Dashboard — Login'],
  ['/dashboard/home', 'Dashboard — Home'],
];

export default function Home() {
  return (
    <div className="rounded-2xl border border-brand-border bg-brand-surface p-8 shadow-sm">
      <h1 className="text-2xl font-semibold text-brand-text">MediKiosk — base scaffold</h1>
      <p className="mt-2 text-brand-muted">
        This is the project root. Pick a route below to preview its placeholder.
      </p>
      <ul className="mt-6 space-y-2">
        {routes.map(([href, label]) => (
          <li key={href}>
            <Link href={href} className="text-brand-primary underline underline-offset-2">
              {label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
