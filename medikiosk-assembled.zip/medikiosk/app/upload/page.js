'use client';

import { useCallback, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useIntake } from '@/context/IntakeContext';
import translations from '@/lib/translations';
import { mockExtractDocument } from '@/lib/mocks';
// Reusing the same read-aloud stub used on Welcome/Consent, rather than
// building a second one, so behavior stays identical across screens.
import ReadAloudButton from '@/components/welcome/ReadAloudButton';
import DocumentUploadArea from '@/components/upload/DocumentUploadArea';
import UploadedDocumentItem from '@/components/upload/UploadedDocumentItem';

// Client-side hints only — a browser-reported MIME type and file size are
// both trivially spoofable. The real backend MUST independently re-check
// file type (via content/magic-byte sniffing, not the client-supplied MIME
// type) and size before accepting or storing any upload, and these are
// medical documents so it should also run malware/AV scanning before they
// reach storage. See SECURITY.md, "Restrict file uploads".
const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024; // 10MB

function isAcceptedFile(file) {
  return (
    (file.type === 'application/pdf' || file.type.startsWith('image/')) &&
    file.size <= MAX_FILE_SIZE_BYTES
  );
}

export default function UploadPage() {
  const router = useRouter();
  const { language, addUploadedDocument } = useIntake();

  // Local-only list driving this screen's UI (filename, live status, and the
  // extracted preview). IntakeContext.uploadedDocuments is the durable copy
  // other screens (e.g. Summary) will read from — each item is pushed there
  // via addUploadedDocument() once its mockExtractDocument() call resolves.
  const [items, setItems] = useState([]);

  const t = translations[language]?.upload ?? translations.en.upload;

  const handleFilesSelected = useCallback(
    (fileList) => {
      const files = Array.from(fileList || []).filter(isAcceptedFile);

      files.forEach((file) => {
        const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

        setItems((prev) => [
          ...prev,
          { id, name: file.name, size: file.size, status: 'processing', extracted: null },
        ]);

        // Each file gets its own independent mockExtractDocument() call so
        // multiple uploads process concurrently rather than queuing.
        mockExtractDocument(file).then((result) => {
          setItems((prev) =>
            prev.map((it) => (it.id === id ? { ...it, status: 'done', extracted: result } : it))
          );
          addUploadedDocument({
            id,
            fileName: result.fileName,
            documentType: result.documentType,
            extractedFields: result.extractedFields,
            uploadedAt: new Date().toISOString(),
          });
        });
      });
    },
    [addUploadedDocument]
  );

  const handleRemove = useCallback((id) => {
    setItems((prev) => prev.filter((it) => it.id !== id));
    // Note: this only clears the file from this screen's own list. There is
    // no removeUploadedDocument() helper on IntakeContext yet, so an item
    // already digitized and pushed to context stays there — add a helper
    // there (following addUploadedDocument's pattern) if screens need
    // removal to propagate too.
  }, []);

  const isProcessingAny = items.some((it) => it.status === 'processing');

  function handleContinue() {
    router.push('/summary');
  }

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-brand-border bg-brand-surface p-8 shadow-sm">
        <div className="flex items-start justify-between gap-4">
          <h1 className="text-3xl font-semibold text-brand-text">{t.title}</h1>
          <ReadAloudButton label={t.readAloud} />
        </div>

        <p className="mt-4 text-lg text-brand-text">{t.subtitle}</p>

        <div className="mt-8">
          <DocumentUploadArea t={t} onFilesSelected={handleFilesSelected} />
        </div>

        <div className="mt-8 space-y-4">
          {items.length === 0 ? (
            <p className="text-center text-base text-brand-muted">{t.noDocuments}</p>
          ) : (
            items.map((item) => (
              <UploadedDocumentItem key={item.id} item={item} t={t} onRemove={() => handleRemove(item.id)} />
            ))
          )}
        </div>

        <button
          type="button"
          onClick={handleContinue}
          disabled={isProcessingAny}
          className={`mt-8 min-h-[48px] w-full rounded-2xl px-6 py-4 text-lg font-semibold shadow-sm transition ${
            isProcessingAny
              ? 'cursor-not-allowed bg-brand-border text-brand-muted'
              : 'bg-brand-primary text-brand-primaryText hover:opacity-90'
          }`}
        >
          {t.continueButton}
        </button>
        {isProcessingAny && (
          <p className="mt-2 text-center text-sm text-brand-muted" role="status">
            {t.processingHint}
          </p>
        )}
      </div>
    </div>
  );
}
