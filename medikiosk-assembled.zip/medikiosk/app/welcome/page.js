'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useIntake } from '@/context/IntakeContext';
import translations from '@/lib/translations';
import AccessibilityToggle from '@/components/AccessibilityToggle';
import LanguageSelector from '@/components/welcome/LanguageSelector';
import PatientTypeToggle from '@/components/welcome/PatientTypeToggle';
import PatientIdentifierInput from '@/components/welcome/PatientIdentifierInput';
import ReadAloudButton from '@/components/welcome/ReadAloudButton';

export default function WelcomePage() {
  const router = useRouter();
  const { language, setPhone, setAbha } = useIntake();

  // Local to this screen only — not part of IntakeContext's shared shape.
  const [patientType, setPatientType] = useState('new'); // 'new' | 'existing'
  const [identifier, setIdentifier] = useState('');
  const [identifierError, setIdentifierError] = useState(false);

  const t = translations[language]?.welcome ?? translations.en.welcome;

  function handleStart() {
    if (patientType === 'existing') {
      const digitsOnly = identifier.replace(/\D/g, '');
      const isPhone = digitsOnly.length === 10;
      const isAbhaOrAadhaar = digitsOnly.length === 12 || digitsOnly.length === 14;

      if (!isPhone && !isAbhaOrAadhaar) {
        setIdentifierError(true);
        return;
      }

      if (isPhone) {
        setPhone(digitsOnly);
      } else {
        setAbha(digitsOnly);
      }
    }

    router.push('/consent');
  }

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-brand-border bg-brand-surface p-8 shadow-sm">
        <div className="flex items-start justify-between gap-4">
          <h1 className="text-3xl font-semibold text-brand-text">{t.title}</h1>
          <ReadAloudButton label={t.readAloud} />
        </div>

        <div className="mt-8">
          <LanguageSelector />
        </div>

        <div className="mt-8">
          <PatientTypeToggle
            t={t}
            patientType={patientType}
            onChange={(value) => {
              setPatientType(value);
              setIdentifierError(false);
            }}
          />
        </div>

        {patientType === 'existing' && (
          <div className="mt-6">
            <PatientIdentifierInput
              t={t}
              value={identifier}
              onChange={(value) => {
                setIdentifier(value);
                setIdentifierError(false);
              }}
              hasError={identifierError}
            />
          </div>
        )}

        <button
          type="button"
          onClick={handleStart}
          className="mt-10 min-h-[48px] w-full rounded-2xl bg-brand-primary px-6 py-4 text-lg font-semibold text-brand-primaryText shadow-sm hover:opacity-90"
        >
          {t.startButton}
        </button>
      </div>

      {/*
        AccessibilityToggle is already mounted globally in AppShell (rendered
        above every route), so accessibilityMode is reachable from anywhere.
        It is reused — not rebuilt — here as well, front-and-center on the
        very first screen, since this is the highest-value spot for elderly /
        low-literacy / first-time-smartphone users to discover it. If the
        global header toggle is judged sufficient for the product, this
        second instance can simply be deleted — same component, same context,
        no duplicated logic either way.
      */}
      <div className="flex justify-center">
        <AccessibilityToggle />
      </div>
    </div>
  );
}
