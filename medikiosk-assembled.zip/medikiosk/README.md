# MediKiosk — base scaffold

Patient self-service clinical history-taking kiosk for hospital OPDs, plus a
staff dashboard. Next.js (App Router) + Tailwind CSS.

This repo currently contains **scaffold only** — routing, shared state,
theming/accessibility, translation structure, and mock backend stubs. No
screen has real UI yet. Each screen is being built by a different person who
won't be talking to the others, so **read this file before you start.**

## Getting started

```bash
npm install
npm run dev
```

Open `http://localhost:3000` — the root page links to every stub route.

## Folder structure

```
medikiosk/
├── app/                      # Next.js App Router — one folder per route
│   ├── layout.js             # Root layout: wraps everything in IntakeProvider + AppShell
│   ├── page.js                # "/" — index page linking to all routes
│   ├── welcome/page.js        # "/welcome"
│   ├── consent/page.js        # "/consent"
│   ├── intake/page.js         # "/intake"
│   ├── upload/page.js         # "/upload"
│   ├── summary/page.js        # "/summary"
│   └── dashboard/
│       ├── login/page.js      # "/dashboard/login"
│       └── home/page.js       # "/dashboard/home"
├── components/
│   ├── AppShell.jsx           # Layout-level wrapper; applies accessibility theme
│   ├── AccessibilityToggle.jsx# The large-text/high-contrast toggle button
│   └── ScreenPlaceholder.jsx  # Shared placeholder card used by every stub page
├── context/
│   └── IntakeContext.jsx      # Shared state across all screens (see below)
├── lib/
│   ├── translations.js        # All UI copy, per language, per screen
│   ├── mocks.js                # Fake backend functions (stable signatures)
│   └── session.js              # Mock dashboard session (expiry, save/read/clear) — see SECURITY.md
├── styles/
│   └── globals.css            # Tailwind entry + color tokens + font-scale var
├── tailwind.config.js
├── SECURITY.md                # Security checklist: what's done, what needs a real backend
├── .env.example                # Pattern for env vars once real secrets exist
└── package.json
```

## How to add / build a screen

Each screen already has a route file with a `<ScreenPlaceholder />` in it —
you're just replacing the contents of your one file.

1. Open your screen's file, e.g. `app/intake/page.js`.
2. Delete the `<ScreenPlaceholder ... />` and build your real UI there.
3. Pull shared state from context:
   ```jsx
   'use client';
   import { useIntake } from '@/context/IntakeContext';

   export default function IntakePage() {
     const { chiefComplaint, setChiefComplaint, language } = useIntake();
     // ...
   }
   ```
   Any component that reads or writes context needs the `'use client'`
   directive at the top of the file (the route files themselves are fine to
   convert to client components — the placeholders are server components
   only because they don't need state yet).
4. Pull your copy from `translations.js` (see below).
5. Call whichever `mocks.js` functions are relevant to your screen (see
   below) — don't write fetch/API code yet, that comes later when the real
   backend is ready. Keep using the mock and just await it like a real call.
6. Style with Tailwind using the `brand-*` color tokens (`bg-brand-surface`,
   `text-brand-text`, `border-brand-border`, `text-brand-primary`, etc.) and
   `rounded-2xl` for cards, so your screen automatically matches the calm
   palette **and** automatically supports the high-contrast theme. Don't
   hardcode hex colors or px-based font sizes — that's what breaks
   accessibility mode.
7. **Do not touch** `app/layout.js`, `AppShell.jsx`, or `IntakeContext.jsx`
   unless you're adding a genuinely new shared field — if you need a new
   piece of shared state, add it to `IntakeContext.jsx` following the
   existing pattern (state + setter, exposed in the context value) rather
   than inventing local-only state that another screen also needs.

You do not need to touch any other screen's file, and no other screen needs
to touch yours.

## `IntakeContext` — what's available via `useIntake()`

| Field | Type | Notes |
|---|---|---|
| `patientId`, `abha`, `phone` | string \| null | Patient identity, plus setters |
| `language` | string | e.g. `'en'`, `'hi'` — matches keys in `translations.js` |
| `accessibilityMode` | bool | Drives the high-contrast/large-text theme (see below) |
| `consentGiven` | bool | Set by the consent screen |
| `chiefComplaint` | string | Set by the intake screen |
| `historyAnswers` | object | Free-form Q&A map; use `updateHistoryAnswer(key, value)` |
| `uploadedDocuments` | array | Use `addUploadedDocument(doc)` to append |
| `summary` | object \| null | Set once `mockGenerateSummary()` resolves |

Every field has a matching `setXxx` function. Helper functions
(`toggleAccessibilityMode`, `updateHistoryAnswer`, `addUploadedDocument`,
`resetIntake`) are also exposed — prefer those over calling the raw setter
where one exists.

## `translations.js` — structure

```js
{
  en: {
    welcome: { title: '...', startButton: '...' },
    consent: { agree: '...' },
  },
  hi: { welcome: { ... }, consent: { ... } },
  ta: { welcome: { ... }, consent: { ... } },
  bn: { welcome: { ... }, consent: { ... } },
}
```

- Top level = language code (matches `IntakeContext.language`).
- Second level = your screen name (`welcome`, `consent`, `intake`, `upload`,
  `summary`, `login`, `home` — pick something obvious).
- Leaf = the string itself.

**Add your screen's keys to every language block**, not just `en`. If you
don't have a translator yet, put a clearly-fake placeholder in the other
languages rather than leaving the key out entirely — a missing key means
someone's UI silently breaks in that language.

Usage:
```jsx
import translations from '@/lib/translations';
import { useIntake } from '@/context/IntakeContext';

const { language } = useIntake();
const t = translations[language] ?? translations.en;
// <h1>{t.welcome.title}</h1>
```

## `mocks.js` — calling the fake backend

Every function simulates a network call (delay + fake data) and returns a
Promise. Treat these signatures as fixed — when real APIs are wired in,
only the *inside* of these functions changes.

```js
import { mockTranscribeSpeech, mockExtractDocument, mockGenerateSummary,
         mockSubmitToHospitalSystem, mockLogin } from '@/lib/mocks';

const { text, confidence } = await mockTranscribeSpeech(audioBlob);
const extracted = await mockExtractDocument(file);
const summary = await mockGenerateSummary(intakeData);
const result = await mockSubmitToHospitalSystem(summary);
const { success, token, error } = await mockLogin(username, password);
```

Show a loading state while awaiting — the fake delays (0.7–1.5s) are there
on purpose so loading UI isn't an afterthought.

## Accessibility toggle — how it works (don't rebuild this)

The toggle button lives in `AppShell.jsx`, rendered once above every route,
so it's already on every screen automatically. It flips
`IntakeContext.accessibilityMode`, and `AppShell` reacts to that by:

- adding/removing a `theme-high-contrast` class on `<body>` (remaps the
  color CSS variables in `styles/globals.css`), and
- setting the `--font-scale` CSS variable (1 → 1.35), which scales
  `html`'s root font-size and therefore every Tailwind rem-based size
  (`text-*`, `p-*`, `gap-*`, etc.) app-wide.

As a screen builder, you don't need to write any accessibility-specific
code — just use the `brand-*` Tailwind colors and default Tailwind spacing/
font-size utilities, and your screen will already respect both large text
and high contrast.
