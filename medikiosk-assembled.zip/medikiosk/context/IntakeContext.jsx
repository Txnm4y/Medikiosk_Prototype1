'use client';

import { createContext, useContext, useState, useMemo, useCallback } from 'react';

const IntakeContext = createContext(undefined);

const initialState = {
  patientId: null,
  abha: null,
  phone: null,
  language: 'en',
  accessibilityMode: false,
  consentGiven: false,
  chiefComplaint: '',
  historyAnswers: {},
  uploadedDocuments: [],
  summary: null,
};

/**
 * IntakeProvider
 * Wraps the whole app (see app/layout.js). Holds every piece of state that
 * needs to survive a patient's journey across the 5 kiosk screens, plus the
 * language/accessibility prefs which also apply to the dashboard.
 */
export function IntakeProvider({ children }) {
  const [patientId, setPatientId] = useState(initialState.patientId);
  const [abha, setAbha] = useState(initialState.abha);
  const [phone, setPhone] = useState(initialState.phone);
  const [language, setLanguage] = useState(initialState.language);
  const [accessibilityMode, setAccessibilityModeState] = useState(initialState.accessibilityMode);
  const [consentGiven, setConsentGiven] = useState(initialState.consentGiven);
  const [chiefComplaint, setChiefComplaint] = useState(initialState.chiefComplaint);
  const [historyAnswers, setHistoryAnswers] = useState(initialState.historyAnswers);
  const [uploadedDocuments, setUploadedDocuments] = useState(initialState.uploadedDocuments);
  const [summary, setSummary] = useState(initialState.summary);

  const setAccessibilityMode = useCallback((value) => {
    setAccessibilityModeState(Boolean(value));
  }, []);

  const toggleAccessibilityMode = useCallback(() => {
    setAccessibilityModeState((prev) => !prev);
  }, []);

  const updateHistoryAnswer = useCallback((key, value) => {
    setHistoryAnswers((prev) => ({ ...prev, [key]: value }));
  }, []);

  const addUploadedDocument = useCallback((doc) => {
    setUploadedDocuments((prev) => [...prev, doc]);
  }, []);

  /** Clears per-visit clinical data but keeps language + accessibility prefs. */
  const resetIntake = useCallback(() => {
    setPatientId(initialState.patientId);
    setAbha(initialState.abha);
    setPhone(initialState.phone);
    setConsentGiven(initialState.consentGiven);
    setChiefComplaint(initialState.chiefComplaint);
    setHistoryAnswers(initialState.historyAnswers);
    setUploadedDocuments(initialState.uploadedDocuments);
    setSummary(initialState.summary);
  }, []);

  const value = useMemo(
    () => ({
      // patient identity
      patientId,
      setPatientId,
      abha,
      setAbha,
      phone,
      setPhone,

      // preferences (shared with dashboard too)
      language,
      setLanguage,
      accessibilityMode,
      setAccessibilityMode,
      toggleAccessibilityMode,

      // consent + clinical data
      consentGiven,
      setConsentGiven,
      chiefComplaint,
      setChiefComplaint,
      historyAnswers,
      setHistoryAnswers,
      updateHistoryAnswer,
      uploadedDocuments,
      setUploadedDocuments,
      addUploadedDocument,
      summary,
      setSummary,

      // utility
      resetIntake,
    }),
    [
      patientId,
      abha,
      phone,
      language,
      accessibilityMode,
      consentGiven,
      chiefComplaint,
      historyAnswers,
      uploadedDocuments,
      summary,
      setAccessibilityMode,
      toggleAccessibilityMode,
      updateHistoryAnswer,
      addUploadedDocument,
      resetIntake,
    ]
  );

  return <IntakeContext.Provider value={value}>{children}</IntakeContext.Provider>;
}

/**
 * useIntake()
 * Access the shared kiosk state from any screen, e.g.:
 *   const { language, chiefComplaint, setChiefComplaint } = useIntake();
 */
export function useIntake() {
  const ctx = useContext(IntakeContext);
  if (ctx === undefined) {
    throw new Error(
      'useIntake() must be used within an <IntakeProvider>. It is already wired up in app/layout.js — make sure you have not rendered this component outside the app tree.'
    );
  }
  return ctx;
}
