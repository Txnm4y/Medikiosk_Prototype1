'use client';

import { useIntake } from '@/context/IntakeContext';

/**
 * Layout-level control that flips IntakeContext.accessibilityMode.
 * AppShell reacts to that flag by toggling the high-contrast theme class
 * and the --font-scale CSS variable, so every page inherits this for free.
 */
export default function AccessibilityToggle() {
  const { accessibilityMode, toggleAccessibilityMode } = useIntake();

  return (
    <div className="flex justify-end px-4 pt-4">
      <button
        type="button"
        onClick={toggleAccessibilityMode}
        aria-pressed={accessibilityMode}
        className="rounded-2xl border border-brand-border bg-brand-surface px-4 py-2 text-sm font-medium text-brand-text shadow-sm hover:opacity-90"
      >
        {accessibilityMode ? '✓ High-contrast / large text ON' : 'Large text & high contrast'}
      </button>
    </div>
  );
}
