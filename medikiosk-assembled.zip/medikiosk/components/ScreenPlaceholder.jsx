/**
 * Generic placeholder used by every not-yet-built screen. Screen owners
 * should delete this once their real UI is in place — it's here purely so
 * the routing/theming/accessibility can be demoed end-to-end today.
 */
export default function ScreenPlaceholder({ title, description }) {
  return (
    <div className="rounded-2xl border border-brand-border bg-brand-surface p-8 shadow-sm">
      <h1 className="text-2xl font-semibold text-brand-text">{title}</h1>
      {description && <p className="mt-2 text-brand-muted">{description}</p>}
      <p className="mt-6 text-sm text-brand-muted">
        Placeholder screen — build this page&apos;s UI here using{' '}
        <code>useIntake()</code> for state and <code>translations.js</code> for copy.
      </p>
    </div>
  );
}
