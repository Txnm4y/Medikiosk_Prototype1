'use client';

function formatFileSize(bytes) {
  if (!bytes && bytes !== 0) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatDocumentType(documentType) {
  if (!documentType) return '—';
  return documentType.charAt(0).toUpperCase() + documentType.slice(1);
}

function StatusBadge({ status, t }) {
  if (status === 'done') {
    return (
      <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-brand-primary px-3 py-1 text-sm font-medium text-brand-primaryText">
        {t.statusDone}
      </span>
    );
  }
  return (
    <span className="inline-flex shrink-0 items-center gap-2 rounded-full border border-brand-border bg-brand-surface px-3 py-1 text-sm text-brand-muted">
      <span className="h-2 w-2 animate-pulse rounded-full bg-brand-muted" aria-hidden="true" />
      {t.statusProcessing}
    </span>
  );
}

export default function UploadedDocumentItem({ item, t, onRemove }) {
  const fields = item.extracted?.extractedFields;
  const medicines = fields?.medicines;

  return (
    <div className="rounded-2xl border border-brand-border bg-brand-bg p-4">
      <div className="flex items-center gap-3">
        <span className="text-2xl" aria-hidden="true">
          📄
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-base font-medium text-brand-text">{item.name}</p>
          {item.size !== undefined && (
            <p className="text-sm text-brand-muted">{formatFileSize(item.size)}</p>
          )}
        </div>
        <StatusBadge status={item.status} t={t} />
        <button
          type="button"
          onClick={onRemove}
          aria-label={t.removeButton}
          title={t.removeButton}
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-brand-muted transition hover:bg-brand-border hover:text-brand-text"
        >
          ×
        </button>
      </div>

      {item.status === 'done' && fields && (
        <div className="mt-4 rounded-2xl border border-brand-border bg-brand-surface p-4">
          <div className="mb-3 flex items-center gap-2">
            <span aria-hidden="true">📋</span>
            <h3 className="text-sm font-semibold text-brand-text">{t.extractedHeading}</h3>
          </div>
          {/* mockExtractDocument()'s fixed contract returns documentType,
              doctorName, date and medicines — not a distinct "diagnosis"
              field — so Record Type stands in as the closest available
              analog alongside the requested Date/Medication fields. */}
          <table className="w-full text-sm">
            <tbody>
              <tr className="border-b border-brand-border last:border-0">
                <td className="py-2 pr-4 font-medium text-brand-muted">{t.fieldRecordType}</td>
                <td className="py-2 text-brand-text">{formatDocumentType(item.extracted.documentType)}</td>
              </tr>
              <tr className="border-b border-brand-border last:border-0">
                <td className="py-2 pr-4 font-medium text-brand-muted">{t.fieldDoctor}</td>
                <td className="py-2 text-brand-text">{fields.doctorName || '—'}</td>
              </tr>
              <tr className="border-b border-brand-border last:border-0">
                <td className="py-2 pr-4 font-medium text-brand-muted">{t.fieldDate}</td>
                <td className="py-2 text-brand-text">{fields.date || '—'}</td>
              </tr>
              <tr>
                <td className="py-2 pr-4 font-medium text-brand-muted">{t.fieldMedication}</td>
                <td className="py-2 text-brand-text">
                  {Array.isArray(medicines) && medicines.length > 0 ? medicines.join(', ') : '—'}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
