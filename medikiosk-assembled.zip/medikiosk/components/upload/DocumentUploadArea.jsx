'use client';

import { useRef, useState } from 'react';

/**
 * DocumentUploadArea
 * Presentational drag-and-drop dropzone + "Browse Files" / "Use Camera"
 * buttons. All three entry points funnel into the same hidden <input
 * type="file">, so the parent only ever has to handle one
 * onFilesSelected(fileList) callback.
 */
export default function DocumentUploadArea({ t, onFilesSelected }) {
  const fileInputRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);

  function openFileDialog() {
    fileInputRef.current?.click();
  }

  function handleDragOver(e) {
    e.preventDefault();
    setIsDragging(true);
  }

  function handleDragLeave(e) {
    e.preventDefault();
    setIsDragging(false);
  }

  function handleDrop(e) {
    e.preventDefault();
    setIsDragging(false);
    onFilesSelected(e.dataTransfer.files);
  }

  function handleInputChange(e) {
    onFilesSelected(e.target.files);
    // Reset so selecting the same file again still fires onChange.
    e.target.value = '';
  }

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={openFileDialog}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          openFileDialog();
        }
      }}
      onDragOver={handleDragOver}
      onDragEnter={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      aria-label={t.dropzoneLabel}
      className={`cursor-pointer rounded-2xl border-2 border-dashed p-8 text-center transition ${
        isDragging ? 'border-brand-primary bg-brand-bg' : 'border-brand-border bg-brand-bg'
      }`}
    >
      {/* Real camera capture would use the device camera directly (e.g. via
          navigator.mediaDevices.getUserMedia + a <video>/<canvas> capture
          flow, or an <input capture="environment"> on supporting mobile
          browsers) instead of routing through the same file picker. Wired to
          the shared input for now so both entry points are testable with the
          same mock pipeline. */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="image/*,application/pdf"
        onChange={handleInputChange}
        className="hidden"
      />

      <div className="text-4xl" aria-hidden="true">
        ⬆️
      </div>
      <p className="mt-3 text-lg font-medium text-brand-text">{t.dropzoneLabel}</p>
      <p className="mt-1 text-sm text-brand-muted">{t.dropzoneHint}</p>

      <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            openFileDialog();
          }}
          className="min-h-[48px] rounded-2xl border border-brand-border bg-brand-surface px-6 py-3 text-base font-medium text-brand-text transition hover:opacity-80"
        >
          {t.browseButton}
        </button>
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            openFileDialog();
          }}
          className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-2xl bg-brand-primary px-6 py-3 text-base font-medium text-brand-primaryText transition hover:opacity-90"
        >
          <span aria-hidden="true">📷</span>
          {t.cameraButton}
        </button>
      </div>
    </div>
  );
}
