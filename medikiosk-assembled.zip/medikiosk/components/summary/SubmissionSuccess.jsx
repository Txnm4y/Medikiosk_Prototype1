'use client';

/**
 * SubmissionSuccess
 * Shown after mockSubmitToHospitalSystem() resolves. Purely a confirmation
 * state — the actual EMR/ABHA linkage is mocked (see lib/mocks.js), so this
 * only ever displays the fake referenceId that mock returns.
 */
export default function SubmissionSuccess({ t, referenceId, onDone }) {
  return (
    <div className="rounded-2xl border border-brand-border bg-brand-surface p-8 text-center shadow-sm">
      <div
        className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-brand-primary text-3xl text-brand-primaryText"
        aria-hidden="true"
      >
        ✓
      </div>
      <h1 className="mt-6 text-2xl font-semibold text-brand-text">{t.successTitle}</h1>
      <p className="mt-3 text-lg text-brand-text">{t.successBody}</p>
      <p className="mt-1 text-base text-brand-muted">{t.successAbhaNote}</p>

      <div className="mt-6 inline-flex flex-col items-center gap-1 rounded-2xl border border-brand-border bg-brand-bg px-6 py-4">
        <span className="text-sm font-medium text-brand-muted">{t.referenceLabel}</span>
        <span className="text-xl font-semibold tracking-wide text-brand-text">{referenceId}</span>
      </div>

      <button
        type="button"
        onClick={onDone}
        className="mt-8 min-h-[48px] w-full rounded-2xl bg-brand-primary px-6 py-4 text-lg font-semibold text-brand-primaryText shadow-sm transition hover:opacity-90"
      >
        {t.doneButton}
      </button>
    </div>
  );
}
