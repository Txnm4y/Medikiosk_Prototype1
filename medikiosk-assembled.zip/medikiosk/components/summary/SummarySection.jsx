'use client';

// Reusing the exact same audio-icon / read-aloud stub built for the Welcome
// screen so every screen's "listen to this" affordance behaves identically
// (and, later, shares one real-TTS wiring point).
import ReadAloudButton from '@/components/welcome/ReadAloudButton';

/**
 * SummarySection
 * One editable card in the clinical summary: a section header (with its own
 * read-aloud icon, matching the per-screen header pattern used elsewhere)
 * and a plain-text textarea bound back into the parent's local summary
 * state. Patients/staff can correct the AI-assembled text here before the
 * whole summary is submitted.
 */
export default function SummarySection({ title, value, onChange, readAloudLabel, disabled }) {
  return (
    <div className="rounded-2xl border border-brand-border bg-brand-bg p-5">
      <div className="flex items-start justify-between gap-3">
        <h2 className="text-lg font-semibold text-brand-text">{title}</h2>
        <ReadAloudButton label={readAloudLabel} />
      </div>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        rows={4}
        className="mt-3 w-full resize-y rounded-2xl border border-brand-border bg-brand-surface p-4 text-base text-brand-text disabled:cursor-not-allowed disabled:opacity-70"
      />
    </div>
  );
}
