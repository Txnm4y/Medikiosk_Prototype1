'use client';

import { useState } from 'react';

/**
 * Visual-only stub — no real text-to-speech yet.
 *
 * REAL TTS INTEGRATION POINT: replace the body of handleToggle() with a call
 * into an actual TTS engine (e.g. the Web Speech API's SpeechSynthesis, or a
 * hospital-provided TTS service) that reads this screen's current translated
 * strings aloud in IntakeContext.language, and drive `isReadingAloud` from
 * that engine's real playing/paused state instead of local toggle state.
 */
export default function ReadAloudButton({ label }) {
  const [isReadingAloud, setIsReadingAloud] = useState(false);

  function handleToggle() {
    // TODO(real TTS): e.g.
    //   if (!isReadingAloud) ttsEngine.speak(currentScreenText, { lang: language });
    //   else ttsEngine.stop();
    setIsReadingAloud((prev) => !prev);
  }

  return (
    <button
      type="button"
      onClick={handleToggle}
      aria-pressed={isReadingAloud}
      aria-label={label}
      title={label}
      className={`flex min-h-[48px] min-w-[48px] shrink-0 items-center justify-center rounded-2xl border text-xl transition ${
        isReadingAloud
          ? 'border-brand-primary bg-brand-primary text-brand-primaryText'
          : 'border-brand-border bg-brand-surface text-brand-text hover:opacity-80'
      }`}
    >
      {isReadingAloud ? '🔊' : '🔈'}
    </button>
  );
}
