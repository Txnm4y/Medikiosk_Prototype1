'use client';

/**
 * Pure presentational toggle. `patientType` is 'new' | 'existing' and is kept
 * in the parent screen's local state, not IntakeContext — it isn't part of
 * the shared shape and only matters for this screen's own flow.
 */
export default function PatientTypeToggle({ t, patientType, onChange }) {
  return (
    <div className="grid grid-cols-2 gap-3">
      <button
        type="button"
        onClick={() => onChange('new')}
        aria-pressed={patientType === 'new'}
        className={`min-h-[48px] rounded-2xl border px-4 py-3 text-base font-medium transition ${
          patientType === 'new'
            ? 'border-brand-primary bg-brand-primary text-brand-primaryText'
            : 'border-brand-border bg-brand-surface text-brand-text hover:opacity-80'
        }`}
      >
        {t.newPatient}
      </button>
      <button
        type="button"
        onClick={() => onChange('existing')}
        aria-pressed={patientType === 'existing'}
        className={`min-h-[48px] rounded-2xl border px-4 py-3 text-base font-medium transition ${
          patientType === 'existing'
            ? 'border-brand-primary bg-brand-primary text-brand-primaryText'
            : 'border-brand-border bg-brand-surface text-brand-text hover:opacity-80'
        }`}
      >
        {t.existingPatient}
      </button>
    </div>
  );
}
