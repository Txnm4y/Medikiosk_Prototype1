'use client';

import { useIntake } from '@/context/IntakeContext';
import translations from '@/lib/translations';

// Language names are shown in their own native script regardless of which
// language is currently selected — that's how language pickers conventionally
// work — so this is a fixed display list rather than translated strings.
// Codes must match the top-level keys in lib/translations.js.
const LANGUAGES = [
  { code: 'en', label: 'English' },
  { code: 'hi', label: 'हिंदी' },
  { code: 'mr', label: 'मराठी' },
  { code: 'kn', label: 'ಕನ್ನಡ' },
];

export default function LanguageSelector() {
  const { language, setLanguage } = useIntake();
  const t = translations[language]?.welcome ?? translations.en.welcome;

  return (
    <div>
      <p className="mb-3 text-sm font-medium text-brand-muted">{t.languagePrompt}</p>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {LANGUAGES.map(({ code, label }) => {
          const isActive = language === code;
          return (
            <button
              key={code}
              type="button"
              onClick={() => setLanguage(code)}
              aria-pressed={isActive}
              className={`min-h-[48px] rounded-2xl border px-4 py-3 text-base font-medium transition ${
                isActive
                  ? 'border-brand-primary bg-brand-primary text-brand-primaryText'
                  : 'border-brand-border bg-brand-surface text-brand-text hover:opacity-80'
              }`}
            >
              {label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
