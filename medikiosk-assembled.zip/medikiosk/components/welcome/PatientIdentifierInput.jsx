'use client';

/**
 * Shown only for "Existing Patient". Basic format check only (digit count) —
 * no real ABHA/Aadhaar/phone validation. Parent screen decides, on Start,
 * whether the value looks like a phone number (10 digits) or an
 * ABHA/Aadhaar number (12–14 digits) and stores it into IntakeContext.phone
 * or IntakeContext.abha accordingly.
 */
export default function PatientIdentifierInput({ t, value, onChange, hasError }) {
  return (
    <div>
      <label htmlFor="patient-identifier" className="mb-2 block text-sm font-medium text-brand-muted">
        {t.identifierLabel}
      </label>
      <input
        id="patient-identifier"
        type="text"
        inputMode="numeric"
        autoComplete="off"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={t.identifierPlaceholder}
        className={`min-h-[48px] w-full rounded-2xl border bg-brand-surface px-4 py-3 text-lg text-brand-text focus:outline-none focus:ring-2 focus:ring-brand-primary ${
          hasError ? 'border-red-500' : 'border-brand-border'
        }`}
      />
      {hasError && (
        <p className="mt-2 text-sm text-red-600" role="alert">
          {t.identifierError}
        </p>
      )}
    </div>
  );
}
