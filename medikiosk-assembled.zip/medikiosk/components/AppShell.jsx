'use client';

import { useEffect } from 'react';
import { useIntake } from '@/context/IntakeContext';
import AccessibilityToggle from './AccessibilityToggle';

const FONT_SCALE_NORMAL = '1';
const FONT_SCALE_LARGE = '1.35';

/**
 * AppShell
 * Rendered once, inside app/layout.js, around every route. This is the ONE
 * place accessibility mode is wired to actual CSS — individual screens never
 * need to think about it.
 *
 *   accessibilityMode = true  ->  <body class="theme-high-contrast">
 *                                 + --font-scale: 1.35 (scales all rem-based sizes)
 *   accessibilityMode = false ->  normal calm theme, --font-scale: 1
 */
export default function AppShell({ children }) {
  const { accessibilityMode } = useIntake();

  useEffect(() => {
    const body = document.body;
    if (accessibilityMode) {
      body.classList.add('theme-high-contrast');
      body.style.setProperty('--font-scale', FONT_SCALE_LARGE);
    } else {
      body.classList.remove('theme-high-contrast');
      body.style.setProperty('--font-scale', FONT_SCALE_NORMAL);
    }
  }, [accessibilityMode]);

  return (
    <div className="min-h-screen bg-brand-bg text-brand-text">
      <AccessibilityToggle />
      <main className="mx-auto max-w-3xl px-4 py-8">{children}</main>
    </div>
  );
}
